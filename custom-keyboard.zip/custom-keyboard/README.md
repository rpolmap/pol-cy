# Polish Cyrillic Keyboard
Custom Android keyboard: Latin QWERTZ + Cyrillic QWERTZ (Polish 1:1 transliteration), Gboard-style dark theme.
Push to `main` and GitHub Actions builds the APK (Actions tab > latest run > Artifacts).
Enable it in Settings > System > Languages & input > On-screen keyboard.
